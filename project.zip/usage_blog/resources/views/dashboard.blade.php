@extends('layout')

  

@section('content')

<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-8">

            <div class="card">

                <div class="card-body">

                    @if (session('success'))

                        <div class="alert alert-success" role="alert">

                            {{ session('success') }}

                        </div>

                    @endif

                <div class="container">
                        <h2>Featured Blogs</h2>
			<br>
                        @if($blogs->isEmpty())
                                <p>No blogs found.</p>
                        @else
                                <ul>
                                        @foreach($blogs as $blog)
                                                <li>
                                                <h3>{{ $blog->title }}</h3>
                                                <div>
                                                        {{ $blog->content }}
                                                </div>
                                                <hr>
                                                </li>
                                        @endforeach
                                </ul>
                        @endif
                </div> 
                </div>

            </div>

        </div>

    </div>

</div>

@endsection

@extends('layout')

  

@section('content')

<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-8">

            <div class="card">

                <div class="card-header">{{ __('Dashboard') }}</div>

  

                <div class="card-body">

                    @if (session('success'))

                        <div class="alert alert-success" role="alert">

                            {{ session('success') }}

                        </div>

                    @endif

                <div class="container">
                        <h1>All Blogs</h1>

                        @if($blogs->isEmpty())
                                <p>No blogs found.</p>
                        @else
                                <ul>
                                        @foreach($blogs as $blog)
                                                <li>
                                                <h2>{{ $blog->title }}</h2>
                                                <div>
                                                        {!! $blog->content !!} <!-- If the content is HTML, use the {!! !!} syntax to prevent escaping -->
                                                </div>
                                                <hr>
                                                </li>
                                        @endforeach
                                </ul>
                        @endif
                </div> 

                    You are Logged In

                </div>

            </div>

        </div>

    </div>

</div>

@endsection

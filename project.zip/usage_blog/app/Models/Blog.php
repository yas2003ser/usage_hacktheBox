<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    // Define the table name if it's different from the default convention
    protected $table = 'blog';

    // Define the primary key if it's different from the default convention
    // protected $primaryKey = 'id';

    // Define the fillable fields to allow mass assignment
    protected $fillable = [
        'title',
        'content',
        // Add more fields here if needed
    ];

    // Define any additional relationships, attributes, or methods for the Blog model
}

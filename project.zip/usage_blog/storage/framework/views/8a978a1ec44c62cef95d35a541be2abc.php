  

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-8">

            <div class="card">

                <div class="card-body">

                    <?php if(session('success')): ?>

                        <div class="alert alert-success" role="alert">

                            <?php echo e(session('success')); ?>


                        </div>

                    <?php endif; ?>

                <div class="container">
                        <h2>Featured Blogs</h2>
			<br>
                        <?php if($blogs->isEmpty()): ?>
                                <p>No blogs found.</p>
                        <?php else: ?>
                                <ul>
                                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <h3><?php echo e($blog->title); ?></h3>
                                                <div>
                                                        <?php echo e($blog->content); ?>

                                                </div>
                                                <hr>
                                                </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                        <?php endif; ?>
                </div> 
                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/usage_blog/resources/views/dashboard.blade.php ENDPATH**/ ?>